import numpy as np
class n_set:
    def __new__(cls,rng,dict):
        print("Normalizing")
        for i in range(1,rng + 1):
            rang = rng+1
            print(f"Iter : {i} of {rang}")
            dict['D'+str(i)][0] = np.where(np.max(dict['D'+str(i)][0], axis=0)==0, dict['D'+str(i)][0], dict['D'+str(i)][0]*1./np.max(dict['D'+str(i)][0], axis=0))
        return dict             
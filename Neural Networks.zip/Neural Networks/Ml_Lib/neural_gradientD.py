import numpy as np 

class grad:
    def __new__(cls,X,y,theta1,theta2,theta3,itr,alpha,lmd):
        # 
        y = np.array(y)
        y = y.reshape(y.shape[0],1)
        delta1=0
        delta2=0
        delta3=0
        
        
        m = y.shape[0]
        a1 = X
        for i in range(itr):
            
            if (i%10)==0:
                print("Iter " , i)
            
            z2 = X@(theta1)
            from Ml_Lib import neural_sigmoid
            a2 = neural_sigmoid.sigmoid(z2)
           
            
            z3 = a2@(theta2)
            a3 = neural_sigmoid.sigmoid(z3)
         
            z4 = a3@(theta3)
            h = neural_sigmoid.sigmoid(z4)
        
            del4 = h-y
            del3 = (del4@theta3.T)*(a3*(1-a3))
        
            a2 = neural_sigmoid.sigmoid(z2)
            del2 = ((del3@(theta2.T))*(a2*(1-a2)))
           
            
            delta1 = delta1 + (del2.T)@(a1) 
            delta2 = delta2 + (del3.T)@(a2) 
            delta3 = delta3 + (del4.T)@(a3) 
            
            d1 = ((1/m)*(delta1.T)) + (lmd/m)*theta1
            d2 = ((1/m)*(delta2.T)) + (lmd/m)*theta2
            d3 = ((1/m)*(delta3.T)) + (lmd/m)*theta3
            
            d1[:,0] = (1/m)*(delta1.T[:,0])
            d2[:,0] = (1/m)*(delta2.T[:,0])
            d3[:,0] = (1/m)*(delta3.T[:,0])
            
            theta1 = theta1 - (alpha)*(d1)
            theta2 = theta2 - (alpha)*(d2)
            theta3 = theta3 - (alpha)*(d3)
            
            from Ml_Lib import neural_cost
            
            J = neural_cost.cost(y,theta1,theta2,theta3,h,lmd)
            
            
        return theta1,theta2,theta3,h
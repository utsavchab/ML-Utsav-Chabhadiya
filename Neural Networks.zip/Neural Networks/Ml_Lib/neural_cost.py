import numpy as np 

class cost:
    def __new__(cls,y,theta1,theta2,theta3,h,lmd=False):
        
        if lmd == False:
                lmd = 0
        else:
            pass
        m = 88800
        h1 = np.log(h);
        h2 = np.log(1-h);
        
        regt1 = theta1[:,2:]
        regt2 = theta2[:,2:]
        regt3 = theta3[:,2:]
        J  = -(1/m)*((y.T@h1)+ ((1-(y.T))@(h2) ).sum()) +  (lmd/(2*m))*( ((regt1**2).sum()).sum() + ((regt2**2).sum()).sum() + ((regt3**2).sum()).sum())
        
        return J
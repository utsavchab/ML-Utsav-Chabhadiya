import math
import numpy as np

class sigmoid:
    def __new__(cls,z):
        
        h = np.array(1/(1 + np.power(math.exp(1),-z)))
        
        return h
import pandas as pd
class dt: 
    def __new__(cls,data,copy_num,y_name):
        datasets = []
        
        for i in range(copy_num):
            datasets.append(data.copy())
            

        dict={}
        for i in range(1,copy_num+1):
            X = datasets[i-1].iloc[:,1:data.shape[1]] 
            y = pd.get_dummies(data[y_name]).iloc[:,i-1]
            dict['D'+str(i)] = [X,y]
        
        return dict
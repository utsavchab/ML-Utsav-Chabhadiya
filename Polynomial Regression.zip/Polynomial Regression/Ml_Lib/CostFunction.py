import numpy as np

class Cost:     
    def __new__(cls,X,y,theta,Lambda = False):
        
        if Lambda == False:
                Lambda = 0
        else:
            pass
        
        data_count = X.shape[0]
        return (1/(2*data_count)) * (((X@theta - y)*(X@theta - y)).sum()) +(Lambda/(2*data_count))*(theta[1:,:].sum())
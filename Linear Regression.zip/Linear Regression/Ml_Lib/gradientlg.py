import numpy as np
import pandas as pd
from Ml_Lib.CostFunction import Cost


class calculate_theta:
    def __new__(cls,X,y,theta,alpha,iterations,Lambda = False):
        
        if Lambda == False:
            Lambda = 0
        else:
            pass
    
        data_count = X.shape[0]
        
        # J,J_new = Cost(X,y,theta,Lambda)
        J = Cost(X,y,theta,Lambda)
        
        J_Data = {"J":J.sum(), 
                #   "J_Log": J_new.sum()
        }
       
        J_d = pd.DataFrame(J_Data, index =[0])
        
        
        
        for i in range (iterations):
            
            h = X@theta
            
            grad = np.array((1/data_count)*(X.T@(h - y)) + (Lambda/data_count)*theta)
            grad[0,:] = (1/data_count)*(X.T@(h - y))[0,:]
            
            grad = np.array(grad, dtype='float32')
            # print(grad)
            
            
            theta = theta - alpha*(grad)
            
            # J,J_new = Cost(X,y,theta,Lambda)
            J = Cost(X,y,theta,Lambda)
            # J_d.loc[len(J_d.index)] = [J,J_new]
            J_d.loc[len(J_d.index)] = [J]
            
            if i==0:
                pass
            elif i%500 ==0:
                # print(f"Grad. Iteration {i}, J_Log = {J_new}, J = {J} ")
                print(f"Grad. Iteration {i}, J = {J} ")
            else:
                pass
                
            if i%200 == 0:
                print(f'Iteration{i} J =  ',J)
            else:
                pass
            
            if i>=4:
                if i%2 == 0:
                    if abs(J - J_d.iloc[-3,0])<0.00000001:
                        break
                    else:
                        pass
                else:
                    pass
            else:
                pass
        
        
        return theta,J_d,J
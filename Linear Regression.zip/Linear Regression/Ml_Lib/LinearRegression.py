## Documentation
'''
Linear Regression(Regularised and unRegularised)

This is Linear Regression Library

1) fitnormal class uses normal equation to calculate.
2) fit class uses gradient descent to calculate weights.
3) fitReg class uses regularised method to calculate weights and cost.

'''

import numpy as np

class lr:
    
    def __init__(self) :
        print("Linear Regression Model.")
         
    class fitNormal:
        
        def __init__(self,X,y):

        #1)Theta Calculation
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            y = np.array(y)
            y = y.reshape(y.shape[0],1)
            try :
                theta = np.array([np.linalg.inv((X.T@X))@X.T@y]).T
            except ValueError:
                print("Matrix Dimension Mismatch Error")

        #2)Compute Cost Function
            from Ml_Lib import CostFunction
            J = CostFunction.Cost(X, y, theta)
            self.theta = theta
            self.jcalc = J
            self.X =X
            self.y = y
            

        def J_(self):    
            return round(self.jcalc,4)
        def theta_(self):
            return self.theta

        def predict(self,X):
            
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            
            h = X@self.theta
            
            return h
        
        def r2_score(self):
            
            h = np.array(self.X@self.theta)
             
            from Ml_Lib import r2_score
            score = r2_score.r2score(h,self.y)
            return score*100
        
        def r2_score_test(self,X,y):
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = np.array(X@self.theta)
            y = y.reshape(y.shape[0],1)
            
            from Ml_Lib import r2_score
            score = r2_score.r2score(h,y)
           
            return score*100
        
        def rmse_score(self):
            
            h = np.array(self.X@self.theta)
            h = h.reshape(self.y.shape[0],1)
            rmse = (((h-self.y)**2).sum()/h.shape[0])**(1/2)
            
            return rmse
        
        def rmse_score_test(self,X,y):
            
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = np.array(X@self.theta)
            h = h.reshape(y.shape[0],1)
            y = y.reshape(y.shape[0],1)
            rmse = (((h-y)**2).sum()/h.shape[0])**(1/2)
            
            return rmse
        
        
        
            
    class fit:
               
        def __init__(self,X,y,alpha = False):
            
            X = np.c_[ np.ones((X.shape[0],1)) , X ] 
            y = np.array(y)
            y = y.reshape(y.shape[0],1)
            theta = np.zeros((X.shape[1],1))  #(n+1,1)
            iterations = 90000
            
            if (alpha == False):
                alpha = 0.7
            else:
                pass

            # 1) Cost fuction
            from Ml_Lib import CostFunction
            J = CostFunction.Cost(X, y, theta)
            from Ml_Lib import gradientlg
            theta,J_Data,J = gradientlg.calculate_theta(X,y,theta,alpha,iterations)
            self.jcalc = J
            self.theta = theta
            self.X = X
            self.y = y
            self.J_Data = J_Data
            
        def J_(self):    
            return self.jcalc
        def J_history(self):
            return self.J_Data
        def theta_(self):
            return self.theta
        
        def predict(self,X):
            
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            
            h = X@self.theta
            return h
        
        def r2_score(self):
            
            h = np.array(self.X@self.theta)
             
            from Ml_Lib import r2_score
            score = r2_score.r2score(h,self.y)
           # score = np.mean(score)
            return score*100
        
        def r2_score_test(self,X,y):
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = np.array(X@self.theta)
            y = y.reshape(y.shape[0],1)
            
            from Ml_Lib import r2_score
            score = r2_score.r2score(h,y)
           # score = np.mean(score)
            return score*100
        
    
        
        def rmse_score(self):
            
            h = np.array(self.X@self.theta)
            h = h.reshape(self.y.shape[0],1)
            rmse = (((h-self.y)**2).sum()/h.shape[0])**(1/2)
            
            return rmse
        
        def rmse_score_test(self,X,y):
            
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = np.array(X@self.theta)
            h = h.reshape(y.shape[0],1)
            y = y.reshape(y.shape[0],1)
            rmse = (((h-y)**2).sum()/h.shape[0])**(1/2)
            
            return rmse
               
    class fitReg:
               
        def __init__(self,X,y,alpha = False,Lambda = False):
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            y = np.array(y)
            y = y.reshape(y.shape[0],1)
            theta = np.zeros((X.shape[1],1))  #(n+1,1)
            iterations = 90000
            
            if (alpha == False):
                alpha = 0.1
            else:
                pass
            if (Lambda == False):
                Lambda = 50
            else:
                pass
            
            # 1) Cost fuction
            from Ml_Lib import CostFunction
            J = CostFunction.Cost(X, y, theta,Lambda)
            from Ml_Lib import gradientlg
            theta,J_Data,J = gradientlg.calculate_theta(X,y,theta,alpha,iterations,Lambda)
            self.jcalc = J
            self.theta = theta
            self.X = X
            self.y = y
            self.J_Data = J_Data
            
        
        def J_(self):
            return self.J_
        def J_history(self):
            return self.J_Data
        def theta_(self):
            return self.theta
        
        def predict(self,X):
            
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = X@self.theta
            return h
        
        def r2_score(self):
            
            h = np.array(self.X@self.theta)
             
            from Ml_Lib import r2_score
            score = r2_score.r2score(h,self.y)
           
            return score*100
        
        def r2_score_test(self,X,y):
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = np.array(X@self.theta)
            y = y.reshape(y.shape[0],1)
            
            from Ml_Lib import r2_score
            score = r2_score.r2score(h,y)
            return score*100
        
        def rmse_score(self):
            
            h = np.array(self.X@self.theta)
            h = h.reshape(self.y.shape[0],1)
            rmse = (((h-self.y)**2).sum()/h.shape[0])**(1/2)
            
            return rmse
        
        def rmse_score_test(self,X,y):
            
            X = np.array(X)
            X = np.c_[ np.ones((X.shape[0],1)) , X ]
            h = np.array(X@self.theta)
            h = h.reshape(y.shape[0],1)
            y = y.reshape(y.shape[0],1)
            rmse = (((h-y)**2).sum()/h.shape[0])**(1/2)
            
            return rmse
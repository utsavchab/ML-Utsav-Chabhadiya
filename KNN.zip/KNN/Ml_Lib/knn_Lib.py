
import numpy as np
import pandas as pd

class knn:
    def __init__(cls,train_data,test_data,rng,train_label_name,test_label_name):
        
        #1) Data to Binary
        from Ml_Lib import data_to_binary
        train_dict = data_to_binary.dt(train_data,rng,train_label_name)
        print("1 completed")
        
        from Ml_Lib import normalization
        train_dict = normalization.n_set(rng,train_dict)
        
        #2) Test Data to Binary
        from Ml_Lib import data_to_binary
        test_dict = data_to_binary.dt(test_data,rng,test_label_name)
        
        from Ml_Lib import normalization
        test_dict = normalization.n_set(rng,test_dict)
        print("2 completed")
        
        
        #3) Euclidian Distance
        from Ml_Lib import e_distance
        
        alphabets=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
        for i in range(1,20):
            print("Training for alphabet : ",alphabets[i-1])
            X = train_dict['D'+str(i)][0]
            y = train_dict['D'+str(i)][1]
            X_test = test_dict['D'+str(i)][0]
            y_test = test_dict['D'+str(i)][1]
            d = e_distance.dist(X,X_test)
            correct = 0
            for j in range(X_test.shape[0]):
                ind  = d['P'+str(i+1)][0][0]
                y_ans = y[ind]
                y_test_ans = y_test[j]
                if y_ans == y_test_ans :
                    correct +=1
                else:
                    correct +=0
                
            
            accuracy = correct/X_test.shape[0]
            alphabet = alphabets[i-1]
            print(f"Score for {alphabet} is ",accuracy)
        print("--END--")
        
 
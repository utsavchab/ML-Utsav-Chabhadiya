import numpy as np
import math
class sg:
    def __new__(self,X,theta):
       
        z = X@theta
        
        h = np.array(1/(1 + np.power(math.exp(1),-z)))
        return h
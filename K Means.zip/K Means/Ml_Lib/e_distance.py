import numpy as np
class dist:
    def __new__(cls,X_train,X_test):
        distance = {}
        X_train = np.array(X_train)
        X_test = np.array(X_test )
    
        for i in range(X_test.shape[0]):
            if i%500 == 0:
                print("Iter : ",i)
            else:
                pass
            
            d = (((X_train - X_test[i,:])**2).sum(axis = 1))**(1/2)
            d = d.reshape((X_train.shape[0],1))  
            index = np.arange(0,X_train.shape[0])
            index = index.reshape((X_train.shape[0],1))
            d = np.c_[index,d]
            distance["P"+str(i+1)]= d
            distance['P'+str(i+1)] = distance['P'+str(i+1)][distance['P'+str(i+1)][:,1].argsort()]
        return distance